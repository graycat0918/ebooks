package main

type nikeShoe struct {
	shoe
}
