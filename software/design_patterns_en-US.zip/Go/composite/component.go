package main

type component interface {
	search(string)
}
